import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.html',

})
export class LoginComponent implements OnInit {
  Otp=true;
  Password=true;
  displayForm=true;


  angForm=new FormGroup({
    name: new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(8)]),
    address: new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(8)])
  })

  dispEmp(event){
    this.displayForm = false;
    this.Password = true;
    this.Otp=true;
    }
   dispAdmin(event){
  this.Password = false;
  this.Otp=true;   
}
  
   dispCust(event){
    this.Password =true;
    this.Otp=false;
   }


   constructor(private fb: FormBuilder) {
   
  }

  ngOnInit(): void {
  
  
  }
  
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ifelsedemo',
  templateUrl: './demoComponent.html',
 
})
export class IfElseComponent implements OnInit {

  people: any[]=[
    {
      "name":"Gauri",
      "age": 22
    },
    {
      "name":"Payal",
      "age": 28
    },
    {
      "name":"Pranali",
      "age": 30
    },
    {
      "name":"Snehal",
      "age": 19
    },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}

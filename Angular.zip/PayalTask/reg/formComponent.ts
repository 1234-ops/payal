import { Component } from '@angular/core';

@Component({
  selector: 'app-regform',
  templateUrl: './formComponent.html',
 
})
export class RegistrationComponent {

  displayText= true;
  show= true;

  DisplayText(){
    this.displayText=false;
  }

  DisplayInputFields(){
    this.show= false;
  }
}

import { Component } from "@angular/core";

@Component({
    selector:'two',
    templateUrl:'p1.html'
})
export class TwoWay{
name="ajay";

}

import { Component } from "@angular/core";

  @Component({
    selector: 'my-app',
    templateUrl:'p.html'
  })
  export class AppComponent {
    data="";
       onSaveName(name) {
        
        this.data=(name).value;
    console.log(name.value);
    }
  }
